'use strict';

const api = require('./src/api');

api.listen(3000);
console.log('API Listening on Port 3000');