'use strict';

module.exports = 'my secret token';