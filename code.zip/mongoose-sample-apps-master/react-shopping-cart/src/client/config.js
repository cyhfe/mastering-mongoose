module.exports = {
  stripePublicKey: 'pk_test_CY6HxyQkOolO1B3h43MvkJE5'
};