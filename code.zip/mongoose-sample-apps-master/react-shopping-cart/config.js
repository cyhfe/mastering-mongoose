module.exports = {
  port: 3000,
  stripePrivateKey: 'sk_test_mWzrKuoRNt58LHIreHfGRcTU',
  mongodbUri: 'mongodb://localhost:27017/test'
};